import * as React from "react"
import { CssVarsProvider, extendTheme, Theme } from "@mui/joy/styles"
import CssBaseline from "@mui/joy/CssBaseline"
import Box from "@mui/joy/Box"
import Stack from "@mui/joy/Stack"

import NavBar from "./components/NavBar"
import RentalCard from "./components/RentalCard"
import HeaderSection from "./components/HeaderSection"
import Search from "./components/Search"
import Filters from "./components/Filters"
import Pagination from "./components/Pagination"
import { Card } from "@pihanga2/core"
import renderNavbar from "./navBar.component"
import { PageD3Props } from "./pageD3.types"
import renderHeader from "./header.component"

// const theme: Theme = extendTheme({
//   components: {
//     JoySkeleton: {
//       defaultProps: {
//         animation: 'wave',
//       },
//     },
//   },
// });

export default function RentalDashboard() {
  const props: PageD3Props = {
    navBar: {
      title: "ACME",
      user: {
        name: "Max Ott",
        email: "max@csiro.au",
      },
      showColorSchemeToggle: true,
    },
    pageHeader: {
      title: "Some Page Title",
      subTitle: "... sub title",
    },
  }

  const windowP = {
    cardType: "joy/window",
    disableTransitionOnChange: true,
  }

  return (
    <Card cardName={windowP} parentCard={""}>
      {/* <NavBar /> */}
      {renderNavbar(props.navBar)}
      <Box
        component={"main"}
        sx={{
          height: "calc(100vh - 55px)", // 55px is the height of the NavBar
          display: "grid",
          // gridTemplateColumns: { xs: 'auto', md: '60% 40%' },
          gridTemplateRows: "auto 1fr auto",
        }}
      >
        {renderStack(props)}
        {renderList()}
        {/* <Pagination /> */}
      </Box>
    </Card>
  )

  // return (
  //   <Card cardName={windowP} parentCard={""}>
  //     {/* <NavBar /> */}
  //     {renderNavbar({ title: "foo" })}
  //     <Card cardName={boxP} parentCard={""}>
  //       {renderStack()}
  //       {renderList()}
  //       {/* <Pagination /> */}
  //     </Card>
  //   </Card>
  // )
}

function renderStack(props: PageD3Props) {
  const p = {
    cardType: "joy/stack",
    joy: {
      sx: {
        backgroundColor: "background.surface",
        px: { xs: 2, md: 4 },
        py: 2,
        borderBottom: "1px solid",
        borderColor: "divider",
      },
    },
  }
  return (
    <Card cardName={p} parentCard={""}>
      {/* <HeaderSection /> */}
      {renderHeader(props.pageHeader)}
      <Search />
    </Card>
  )
}

function renderList() {
  const p = {
    cardType: "joy/stack",
    spacing: 2,
    joy: {
      sx: { px: { xs: 2, md: 4 }, pt: 2, minHeight: 0 },
    },
  }
  return (
    <Card cardName={p} parentCard={""}>
      <Filters />
      {renderRentalList()}
    </Card>
  )
}

function renderRentalList() {
  const p = {
    cardType: "joy/stack",
    spacing: 2,
    joy: {
      sx: { overflow: "auto" },
    },
  }
  return (
    <Card cardName={p} parentCard={""}>
      <RentalCard
        title="A Stydslish Apt, 5 min walk to Queen Victoria Market"
        category="Entire apartment rental in Collingwood"
        rareFind
        image="https://images.unsplash.com/photo-1568605114967-8130f3a36994?auto=format&fit=crop&w=400"
      />
    </Card>
  )
}

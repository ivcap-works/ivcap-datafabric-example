import * as React from "react"
import JoyCard from "@mui/joy/Card"
import CardContent from "@mui/joy/CardContent"
import JoyLink from "@mui/joy/Link"
import JoyStack from "@mui/joy/Stack"
import JoyTypography from "@mui/joy/Typography"
import { Card, PiCardProps } from "@pihanga2/core"
import { Card as PiCard, Typography, Link } from "@pihanga2/cards"

import type { VariantT } from "@pihanga2/cards"

type RentalCardProps = {
  category: React.ReactNode
  image: string
  liked?: boolean
  rareFind?: boolean
  title: React.ReactNode
}

export default function RentalCard(props: RentalCardProps) {
  return V2(props)
}

function V1(props: RentalCardProps) {
  const cardSx = {
    // bgcolor: "neutral.softBg",
    // display: "flex",
    // flexDirection: { xs: "column", sm: "row" },
    "&:hover": {
      boxShadow: "lg",
      borderColor: "var(--joy-palette-neutral-outlinedDisabledBorder)",
    },
  }
  return (
    <JoyCard variant="soft" orientation="horizontal" sx={cardSx}>
      <CardContent>
        <JoyStack
          spacing={1}
          direction="row"
          sx={{ justifyContent: "space-between", alignItems: "flex-start" }}
        >
          <div>
            <JoyTypography level="title-md">
              <JoyLink
                overlay
                underline="none"
                href="#interactive-card"
                sx={{ color: "text.primary" }}
              >
                {props.title}
              </JoyLink>
            </JoyTypography>
          </div>
        </JoyStack>
      </CardContent>
    </JoyCard>
  )
}

function V3(props: RentalCardProps) {
  const cardSx = {
    "&:hover": {
      boxShadow: "lg",
      borderColor: "var(--joy-palette-neutral-outlinedDisabledBorder)",
    },
  }
  return (
    <JoyCard variant="soft" orientation="horizontal" sx={cardSx}>
      <CardContent>
        {/* <Stack
          spacing={1}
          direction="row"
          sx={{ justifyContent: "space-between", alignItems: "flex-start" }}
        > */}
        {/* <div> */}

        <JoyLink
          overlay
          underline="none"
          href="#interactive-card"
          sx={{ color: "text.primary" }}
        >
          <JoyTypography level="title-md">
            {props.title}
          </JoyTypography>
        </JoyLink>

        <JoyTypography >{props.title}</JoyTypography>
        {/* </div> */}
        {/* </Stack> */}
      </CardContent>
    </JoyCard>
  )
}

function V2(props: RentalCardProps) {
  const role = "Background Research Agent"
  const goal =
    "Conduct background research on the given topic: ##research_topic## and keywords ##keywords##. Identify key concepts, current state of knowledge, and potential research questions."

  const rt = Link({
    text: role,
    level: "title-md",
    overlay: true,
    noWrap: true,
  })
  const gt = Typography({ text: goal, noWrap: false })
  const outer = PiCard({
    content: [{ content: rt }, { content: gt }],
    variant: "soft",
    shadowSize: "lg",
  })

  return <Card cardName={outer} parentCard=""></Card>
}

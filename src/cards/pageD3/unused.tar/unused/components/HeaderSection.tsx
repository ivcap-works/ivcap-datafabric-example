import * as React from 'react';
import Stack from '@mui/joy/Stack';
import Typography from '@mui/joy/Typography';
import { Card } from '@pihanga2/core';

export default function HeaderSection() {
  return render2()
}

function render() {
  return (
    <Stack sx={{ mb: 2 }}>
      <Stack direction="row" sx={{ justifyContent: 'space-between', width: '100%' }}>
        <Typography level="h2">Rental properties</Typography>
      </Stack>
      <Typography level="body-md" color="neutral">
        Book your next stay at one of our properties.
      </Typography>
    </Stack>
  );

}

function render2() {
  const stack1 = {
    cardType: "joy/stack",
    joy: {
      sx: { mb: 2 },
    },
  }
  const stack2 = {
    cardType: "joy/stack",
    direction: "row",
    justifyContent: 'space-between',
    joy: {
      sx: { width: '100%' },
    },
  }
  return (
    <Card cardName={stack1} parentCard={""}>
      <Card cardName={stack2} parentCard={""}>
        <Typography level="h2">XRental properties</Typography>
      </Card>
      <Typography level="body-md" color="neutral">
        XBook your next stay at one of our properties.
      </Typography>
    </Card>
  );

}
